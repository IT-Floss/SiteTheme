interface Persona {
    nombre: string;
    apellido: string;
    edad?: number;
}

function hola(persona: Persona) {
    return "Hola, " + persona.nombre + " " + persona.apellido;
}

const personaComun = { nombre: "Peter", apellido: "Parker" };

console.log(hola(personaComun));
