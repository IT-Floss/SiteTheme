function noHagoNada<T>(arg: T): T {
    return arg;
}

console.log(noHagoNada(4), noHagoNada("cuatro"));
