// tipos de datos
//      boolean, number, string, array
//      enum, any, void, tuple, never, null, undefined
//      variables multi-tipo
//      variables opcionales
//      tipos en funciones
//      generics
// interfaces
//      definición y conceptos básicos
//      propiedades indexables
//      propiedades multi-valor
//      enums
//      extender interfaces
//      fusionar interfaces
// clases
//      constructor
//      acceso (privado, público, protegido)
//      propiedades y métodos estáticos
//      extender clases, clases abstractas, clases como interfaces
// decoradores
// TSX
