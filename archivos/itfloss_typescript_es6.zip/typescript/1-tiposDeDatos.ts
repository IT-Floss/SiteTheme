let vf: boolean = true;
let numero: number = 0;
let cadena: string = "0";
let arrayDeString: Array<string> = [ "1", "2", "3" ];
let numeroString: string | number = "1";
let cuadrado;

// vf = false;
// vf = 0;
// vf = null;

// let cuadrado = numero * numero;
// let cuadrado = numero * cadena;

// arrayDeString = [ 1, 2, 3 ];

numeroString = 10;
numeroString = "10";

console.log("valores: ", vf, numero, cadena, arrayDeString, numeroString);
console.log("más valores: ", cuadrado, arrayDeString.length);
