export interface Persona {
    nombre: string;
    apellido: string;
    genero: "Masculino" | "Femenino";
    edad?: number;
    toString: () => string;
}

let chango: Persona = {
    apellido: "Dominguez",
    nombre: "Sebastián",
    genero: "Masculino",
    toString: () => `${this.apellido}, ${this.nombre}`,
};

const imprimirDatos = (persona: Persona) => console.log(`${persona.apellido}, ${persona.nombre}`);
imprimirDatos(chango);

interface Diccionario {
    idioma: string;
    [ palabra: string ]: string;
}
const palabras: Diccionario = {
    idioma: "castellano",
    hola: "saludo",
    chau: "saludo de despedida",
};

console.log(palabras);
