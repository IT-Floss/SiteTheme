abstract class Animal {
    constructor(protected _cantPatas: number, protected _tipo: string) {
    }

    // accessors
    get cantPatas(): number {
        return this._cantPatas;
    }
    set cantPatas(cantPatas: number) {
        this._cantPatas = cantPatas;
    }
    get tipo(): string {
        return this._tipo;
    }
    set tipo(tipo: string) {
        this._tipo = tipo;
    }

    toString() {
        return `Soy un ${this._tipo} y tengo ${this._cantPatas} patas.`;
    }

    // miembros estáticos
    static tipos(): string[] {
        return [ "mamífero", "ave", "reptil", "anfibio", "pez" ];
    }
}

class Pez extends Animal {
    constructor() {
        super(0, "pez");
    }

    toString(): string {
        return `Soy un ${this._tipo} y no tengo patas.`;
    }
}

class Cebra extends Animal {
    constructor(_cantPatas: number, _tipo: string) {
        super(_cantPatas, _tipo);
    }
}

const nemo: Pez = new Pez();
const marty: Animal = new Cebra(4, "mamífero");
// const dodo:Animal = new Animal(2, "ave");
console.log(marty.toString());
console.log(nemo.toString());
console.log(Animal.tipos());
