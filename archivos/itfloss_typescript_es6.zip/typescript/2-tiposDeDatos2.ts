enum Generos {
    masculino,
    femenino,
}

let genero: Generos = Generos.femenino;

let libre: any = "Pepe";
libre = 0;
libre = false;
libre = [ 1, 2, 3 ];

let tupla: [ string, number ];
tupla = [ "cero", 0 ];
// tupla = [ "cero", "0" ];

genero = null;
tupla = undefined;
