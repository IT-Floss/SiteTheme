enum Generos {
    Masculino = 1,
    Femenino
}

interface OtraPersona {
    nombre: string;
    apellido: string;
    genero: Generos;
    fechaNac?: Date;
    toString: () => string;
}

const miOtraPersona: OtraPersona = {
    nombre: "Lynda",
    apellido: "Carter",
    genero: Generos.Femenino,
};

console.log(miOtraPersona);
