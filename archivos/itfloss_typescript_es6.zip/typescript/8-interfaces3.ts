enum ClasificacionAnimal {
    Mamifero,
    Ave,
    Reptil,
    Anfibio,
    Pez
}

interface Animalito {
    tipo: ClasificacionAnimal;
    nombre: string;
}

interface Mamifero extends Animalito {
    cantPatas: number;
}

const perro: Mamifero = {
    tipo: ClasificacionAnimal.Mamifero,
    nombre: "Perro",
    cantPatas: 4,
};

interface Robot {
    duracionBateria: number;
    velocidadCarga: number;
}

interface MascotaRobot extends Robot, Animalito {
    tieneConexionAInternet: boolean;
}

const perrobot: MascotaRobot = {
    tipo: ClasificacionAnimal.Mamifero,
    nombre: "Perro",
    duracionBateria: 12,
    velocidadCarga: 1,
    tieneConexionAInternet: true,
};

console.log(perrobot);
