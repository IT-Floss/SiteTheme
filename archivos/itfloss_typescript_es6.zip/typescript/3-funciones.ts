const nombre = "Seba";

function chau(elNombre) {
    return "Se va " + elNombre;
}
console.log(chau(nombre));

function chauTipada(elNombre: string): string {
    return "Se va " + elNombre;
}
console.log(chauTipada(nombre));

const chauTipadaArrowInferida = (elNombre: string): string => "Se va " + elNombre;
const chauTipadaArrowFull: (p: string) => string = (elNombre: string): string => "Se va " + elNombre;
console.log(chauTipadaArrowInferida(nombre), chauTipadaArrowFull(nombre));

function conOverload(unNumero: number): string;
function conOverload(unaCadena: string): string;
function conOverload(algo: any): string {
    if (typeof algo === "number") {
        return "Se envió el número " + algo.toString();
    } else {
        return "Se envió el texto " + algo;
    }
}

console.log(conOverload(7));
console.log(conOverload("7"));

