function timeout(duracion = 0) {
    return new Promise((resolve, reject) => {
        console.log(`se viene un timeout de ${duracion} milisegundos`)
        setTimeout(resolve, duracion);
    });
}

var p = timeout(1000).then(() => {
    console.log("primer timeout de 1000 milisegunds completo, voy a disparar otro...");
    return timeout(2000);
}).then(() => {
    console.log("timeout de 2000 milisegunds completo, voy a causar un error para ver el catch...");
    throw new Error("hmm");
}).catch(err => {
    console.log("error atrapado, voy a correr los dos timeout en paralelo ahora...");
    return Promise.all([ timeout(1000), timeout(2000) ]);
}).then(() => {
    console.log("el run en paralelo terminó, ahora los vuelvo a ejecutar en paralelo pero me quedo con el que primero regrese...");
    return Promise.race([ timeout(2000), timeout(1000) ]);
}).then(() => {
    console.log("basta de promesas, queremos hechos.");
}).catch(err => {
    console.log("este error no estaba previsto... ☢", err);
});
