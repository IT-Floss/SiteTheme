class Animal {
  constructor(cantPatas, tipo){
    this._cantPatas = cantPatas;
    this._tipo = tipo;
  }
  
  get cantPatas() {
    return this._cantPatas;
  }
  
  set cantPatas(cantPatas) {
    this._cantPatas = cantPatas;
  }
  
  get tipo() {
    return this._tipo;
  }
  
  set tipo(tipo) {
    this._tipo = tipo;
  }
  
  toString() {
    return `Soy un ${this._tipo} y tengo ${this._cantPatas} patas.`;
  }

  static tipos() {
    return ['mamífero', 'ave', 'reptil', 'anfibio', 'pez'];
  }  
}


const tigre = new Animal(4, 'mamífero');
const tiburon = new Animal();
tiburon.cantPatas = 0;
tiburon.tipo = 'pez';
console.log(`El tiburón tiene ${tiburon.cantPatas} patas`);

console.log('Tigre: ' + tigre.toString(), 'Tiburón: ' + tiburon.toString());

class Pez extends Animal {
  constructor(){
    super(0, 'pez');
  }

  toString() {
    return `Soy un ${this._tipo} y no tengo patas.`;
  }
}

const otroTiburon = new Pez();
console.log('Otro tiburón: ' + otroTiburon.toString());
