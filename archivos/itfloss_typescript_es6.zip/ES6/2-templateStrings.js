const str1 = `'Backticks' como delimitadores de strings,
no necesito \\n para
una nueva línea`;

const usuario = {
    nombre: 'Alejandro',
    edad: 29,
};

console.log(str1, '\n');
console.log(`Me llamo ${usuario.nombre} y tengo ${usuario.edad} años.`);
