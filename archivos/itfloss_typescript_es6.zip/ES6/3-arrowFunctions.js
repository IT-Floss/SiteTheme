const comun = function(texto) {
  return 'función común recibió ' + texto;
};

const arrowFull = (texto) => {
  return 'función arrow full full recibió ' + texto;
};

const arrowSmall = texto => 'función arrow simple recibió ' + texto;

console.log(comun('hola mundo'));
console.log(arrowFull('hola mundo'));
console.log(arrowSmall('hola mundo'));


const numeros = [1, 2, 3, 4, 5];

const duplicarComun = numeros.map(function(nro) { return nro * 2; });
const duplicarArrow = numeros.map(nro => nro * 2);

console.log(duplicarComun);
console.log(duplicarArrow);
