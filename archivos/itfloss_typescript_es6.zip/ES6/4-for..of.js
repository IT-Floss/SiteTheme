const arrayDeImpares = [1, 3, 5, 7, 9];

const imprimirPares = impares => {
  for(let nro of impares) {
    console.log(nro + 1);
  }
};

imprimirPares(arrayDeImpares);
