function constYlet() {
  {
    let x = 'valor inicial';
    {
      const x = "nuevo valor";
      console.log('dentro del bloque x vale ' + x);
      // error, const
      // x = "esto no va a funcionar...";
      console.log('x vale ' + x);
    }
    // let x = "esto tampoco va a funcionar...";
    console.log('fuera del bloque x vale ' + x);
  }
}

constYlet();
