// const & let
// Template strings
// Arrow functions
// for-of loop, new methods for common types
// Destructuring / Rest Operator / Spread Operator
// Default parameters
// Classes
// Modules
// Promises
// ES7 -> Decorators, async await
