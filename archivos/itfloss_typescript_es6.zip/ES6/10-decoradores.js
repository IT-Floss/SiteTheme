function agregarDespedida(target) {
    target.prototype.despedirse = (persona) => {
        return `Adios ${persona.nombre}!`;
    }
    return target;
}

@agregarDespedida
class Persona {
    constructor(nombre) {
        this.nombre = nombre;
    }
    saludar() {
        return `Hola soy ${this.nombre}`;
    }
}
const persona = new Persona('Pedro');
console.log(persona.saludar);
console.log(persona.despedirse(persona));
