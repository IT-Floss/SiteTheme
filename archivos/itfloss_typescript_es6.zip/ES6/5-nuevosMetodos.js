console.log(Number.EPSILON, `
Todo numero finito positivo dividido cero resulta en infinito: ${(1/0===Number.POSITIVE_INFINITY)}
5.1 es entero? ${Number.isInteger(5.1)}
NaN: ${Number.isNaN(NaN)}`);

console.log('0b111110111 === 503: ' + (0b111110111 === 503), '0o767 === 503: ' + (0o767 === 503));
console.log('Tiene "cd": ' + ("abcde".includes("cd") ? 'Sí' : 'No'), 'Repetir 3 veces: ' + "Candy Man ".repeat(3));

const capitales = {
    Argentina: 'Buenos Aires',
    Uruguay: 'Montevideo',
    Brasil: 'Brasilia',
    Chile: 'Santiago de Chile',
}
console.log('Object keys: ' + Object.keys(capitales));
console.log('Object values: ' + Object.values(capitales));
console.log('Array de paises: ' + Array.from(Object.keys(capitales)));
console.log('Array "of": ' + Array.of(1, 2, 3));

console.log('Array fill: ' + [ 0, 1, 2, 3 ].fill(7, 2));
console.log('Array find: ' + [ 10, 20, 30 ].find(x => x > 15));
console.log('Array findIndex: ' + [ 10, 20, 30 ].findIndex(x => x > 15));
console.log('Array copyWithin: ' + [ 1, 2, 3, 4, 5 ].copyWithin(3, 0));
console.log('Array entries: ' + [ "a", "b", "c" ].entries());
console.log('Array keys: ' + [ "a", "b", "c" ].keys());

console.log('Object assign sin sobreescribir: ', Object.assign({}, capitales, { Peru: 'Lima' }));
console.log('nuevas capitales: ', capitales);
console.log('Object assign sobreescribiendo: ', Object.assign(capitales, { Peru: 'Lima' }));
console.log('nuevas capitales: ', capitales);
