//jshint esnext:true
const personaje = {
  nombre: 'Alejandro',
  apellido: 'Brozzo',
  edad: 29,
  direccion: {
    calle: 'Avenida Siempreviva',
    numero: 742,
    localidad: 'Rosario',
    pais: 'Argentina'
  }
};

// destructuring
const nombreCompleto = ({nombre, apellido}) => nombre + ' ' + apellido;
console.log('Yo soy ' + nombreCompleto(personaje));

// destructuring + rest
//const todoMenosNombre = ({nombre, apellido, ...resto}) => resto;
//console.log(todoMenosNombre(personaje));

// destructuring + valor por defecto
const nombreAunMasCompleto = ({nombre, segundoNombre = '', apellido, apellidoMaterno = '(sin apellido materno)'}) => `${nombre} ${segundoNombre} ${apellido} ${apellidoMaterno}`;
console.log(nombreAunMasCompleto(personaje));

const coordenadas = [4, 8];
const imprimirCoordenadas = (x=0, y=0, z=0) => console.log(`Las coordenadas son x: ${x}, y: ${y}, z: ${z}.`);

// esto no va a imprimir correctamente, pero muestra los valores por defecto
imprimirCoordenadas(coordenadas);
// spread + valor por defecto
//imprimirCoordenadas(...coordenadas);
